<?php
	include ('mail.php');	
?>  
<!DOCTYPE html>
<html lang="en">
  <head>
  	
    <title>SHANTHINIKETHANA SCHOOL - ADMISSIONS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
	  <div class="bg-top navbar-light">
    	<div class="container">
    		<div class="row no-gutters d-flex align-items-center align-items-stretch">
    			<div class="col-md-4 d-flex align-items-center py-4">
    				<a class="navbar-brand" href="index.html">	<img src="./images/logo.png"><span></span></a>

    			</div>
	    		<div class="col-lg-8 d-block">
		    		<div class="row d-flex">
					  <!--  <div class="col-md d-flex topper align-items-center align-items-stretch py-md-4">
					    	<div class="icon d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
					    	<div class="text">
					    		<span>Email</span>
						    	<span>youremail@email.com</span>
						    </div>
					    </div>-->
					  
					    <div class="col-md topper d-flex align-items-center justify-content-end" style="width: 338px;">
					    	<p class="mb-0">
					    		<br>
					    		<a href="#Admission" class="btn py-2 px-3 btn-primary d-flex align-items-center justify-content-center">

					    			<span>Admissions Open </span>
					    		</a>
					    		<a href="#Admission" class="btn py-2 px-3 btn-primary d-flex align-items-center justify-content-center">

					    			<span>From Pre Kg to 10th Standard </span>
					    		</a>
					    	</p>
					    </div>
				    </div>
			    </div>
		    </div>
		  </div>  
		<!--  <section class="home-slider owl-carousel">
      <div class="slider-item" style="background-image:url(images/banner2.png);">
      	<div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-md-6 ftco-animate">
            <h2 class="mb-4" style="color: #fff;">WELCOME TO SHANTHINIKETHANA PARIWAR</h2>
            <p>We envision to nurture diversity in education that fosters their creativity, a healthy lifestyle and promoting progressive thinking and being Future-ready.</p>
            <p><a href="#" class="btn btn-primary px-4 py-3 mt-3">Contact Us</a></p>
          </div>
        </div>
        </div>
      </div>

      <div class="slider-item" style="background-image:url(images/banner1.png);">
      	<div class="overlay"></div>
        <div class="container">
          <div class="row no-gutters slider-text align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-md-6 ftco-animate">
          <h2 class="mb-4" style="color: #fff;">WELCOME TO SHANTHINIKETHANA PARIWAR</h2>
              <p>We envision to nurture diversity in education that fosters their creativity, a healthy lifestyle and promoting progressive thinking and being Future-ready.</p>
             <p><a href="#" class="btn btn-primary px-4 py-3 mt-3">Contact Us</a></p>
          </div>
        </div>
        </div>
      </div>
    </section>-->


    </div>
	
 
<section >


<div class="slider-wrapper" >
  <div class="slider" style="margin-bottom: 60px;">
    <input type="radio" name="slider" class="trigger" id="one" checked="checked" />
    <div class="slide">
      <figure class="slide-figure">
        <img class="slide-img" src="./images/banner2.jpg" />
      </figure><!-- .slide-figure -->
    </div><!-- .slide -->
    
  <ul class="slider-nav">
    <li class="slider-nav__item"><label class="slider-nav__label" for="one">1</label></li>
    <li class="slider-nav__item"><label class="slider-nav__label" for="two">2</label></li>
  </ul><!-- .slider-nav -->
</div><!-- .slider-wrapper -->
</section>







    <section class="ftco-services ftco-no-pb" >
			<div class="container-wrap">
				<div class="row no-gutters">
          <div class="col-md-3 d-flex services align-self-stretch py-5 px-4 ftco-animate bg-primary">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            		<span class="flaticon-teacher"></span>
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">Certified Teachers</h3>
                <p>The school has appointed well qualified, trained and experienced teachers.They are dedicated to impart quality education through modern methodology. 
</p>
              </div>
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch py-5 px-4 ftco-animate bg-darken">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            		<span class="flaticon-reading"></span>
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">Special Education</h3>
                     <p>Adhering to ethical and moral principles. Enhancing the values of life and culture, arising from the sense of right and wrong. 
</p>
          </div>
            </div>    
          </div>
          <div class="col-md-3 d-flex services align-self-stretch py-5 px-4 ftco-animate bg-primary">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            		<span class="flaticon-books"></span>
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">Labs</h3>
                <p>We have Digital Apple and Creative Lab,Science Lab,Math- Lab, AV Room, Library</p>
               </div>
            </div>      
          </div>
          <div class="col-md-3 d-flex services align-self-stretch py-5 px-4 ftco-animate bg-darken">
            <div class="media block-6 d-block text-center">
              <div class="icon d-flex justify-content-center align-items-center">
            		<span class="flaticon-diploma"></span>
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">Physical Activities</h3>
                <p>We train our students with Yoga, Takewondo, Sports etc., for overall fitness of a child.</p>
               </div>
            </div>      
          </div>
        </div>
			</div>
		</section>
		
		

	<!--	<section class="ftco-section">
			<div class="container-fluid px-4">
				<div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            <h2 class="mb-4"><span>Our</span> Courses</h2>
            <p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
          </div>
        </div>	
				<div class="row">
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/course-1.jpg);"></div>
						<div class="text pt-4">
							<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>
							<h3><a href="#">Electric Engineering</a></h3>
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<p><a href="#" class="btn btn-primary">Apply now</a></p>
						</div>
					</div>
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/course-2.jpg);"></div>
						<div class="text pt-4">
							<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>
							<h3><a href="#">Electric Engineering</a></h3>
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<p><a href="#" class="btn btn-primary">Apply now</a></p>
						</div>
					</div>
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/course-3.jpg);"></div>
						<div class="text pt-4">
							<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>
							<h3><a href="#">Electric Engineering</a></h3>
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<p><a href="#" class="btn btn-primary">Apply now</a></p>
						</div>
					</div>
					<div class="col-md-3 course ftco-animate">
						<div class="img" style="background-image: url(images/course-4.jpg);"></div>
						<div class="text pt-4">
							<p class="meta d-flex">
								<span><i class="icon-user mr-2"></i>Mr. Khan</span>
								<span><i class="icon-table mr-2"></i>10 seats</span>
								<span><i class="icon-calendar mr-2"></i>4 Years</span>
							</p>
							<h3><a href="#">Electric Engineering</a></h3>
							<p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
							<p><a href="#" class="btn btn-primary">Apply now</a></p>
						</div>
					</div>
				</div>
			</div>
		</section>-->



    <section class="ftco-section ftco-consult ftco-no-pt ftco-no-pb" style="background-image: url(images/banner5.png);" data-stellar-background-ratio="0.5">
    	<div class="overlay"></div>
    	<div class="container">
    		<div class="row justify-content-end">
    			<div class="col-md-6 py-5 px-md-5">
    				<div class="py-md-5">
		          <div class="heading-section heading-section-white ftco-animate mb-5" id="Admission">
		            <h2 class="mb-4">Admission Enquiry 2020</h2>
		            <p>Enquiries are made super easy by us. Please fill this form and expect call back from us within 24 hours.</p>
		          </div>
		          <form action="" method="post" class="appointment-form ftco-animate">
		    				<div class="d-md-flex">
			    				<div class="form-group">
			    					<input name="parent name" type="text" class="form-control" placeholder="Parents/Guardian Name">
			    				</div>
			    				<div class="form-group ml-md-4">
			    					<input name="student name" type="text" class="form-control" placeholder="Students Name">
			    				</div>
		    				</div>
							<div class="d-md-flex">
			    				<div class="form-group">
			    					<input name="email" type="email" class="form-control" placeholder="Email">
			    				</div>
			    				<div class="form-group ml-md-4">
			    					<input name="number" type="number" class="form-control" placeholder="Phone No.">
			    				</div>
		    				</div>
		    				<div class="d-md-flex">
		    					<div class="form-group">
			    					<div class="form-field">
		        					<div class="select-wrap">
		                    			 <div class="icon">
		                    			 	<span class="ion-ios-arrow-down"></span></div>
		                    				<select name="Board" id="" class="form-control">
		                    					  <option value="">Select Your Board</option>
		                    					  <option value="STATE"  style="color: #000">STATE</option>
		                    					  <option value="ICSE"  style="color: #000">ICSE</option>
		                    </select>
		                  </div>
			              </div>
			    				</div>
		    					<!--<div class="form-group ml-md-4">
			    					<input type="text" class="form-control" placeholder="Phone">
			    				</div>-->
		    				</div>
		    				<div class="d-md-flex">
		    					<div class="form-group">
			              <textarea name="Queries" id="" cols="30" rows="2" class="form-control" placeholder="Any Queries?"></textarea>
			            </div>
			            <div class="form-group ml-md-4">
			              <input name="submit" type="submit" value="Submit" class="btn btn-primary py-3 px-4">
			            </div>
		    				</div>
		    			</form>
		    		</div>
    			</div>
        </div>
    	</div>
    </section>


		<section class="ftco-section ftco-counter img" id="section-counter" style="background-image: url(images/banner3.jpg);" data-stellar-background-ratio="0.5">
    	<div class="container">
    		<div class="row justify-content-center mb-5 pb-2 d-flex">
    			<div class="col-md-6 align-items-stretch d-flex">
    				<div class="img img-video d-flex align-items-center" style="background-image: url(images/school.jpg);">
    					<div class="video justify-content-center">
									<span class="ion-ios-play"></span>
		  					</a>
							</div>
    				</div>
    			</div>
          <div class="col-md-6 heading-section heading-section-white ftco-animate pl-lg-5 pt-md-0 pt-5">
            <h2 class="mb-4">Shanthinikethana School</h2>
            <p>A warm welcome awaits every student and parent at Shanthinikethana School. You are about to become a part of a very large family, where your wishes and opinion will be welcome. The family must be happy, safe and comfortable in such an environment.Life in a well run school can be full and enjoyable, provided each one is a good citizen and exercise the values of Love, Empathy and Discipline.</p>
            <p>Our vision, mission and motto is to impart education that equips the individual to cope with the diverse needs of the society.</p>
          </div>
        </div>	
    		<div class="row d-md-flex align-items-center justify-content-center">
    			<div class="col-lg-12">
    				<div class="row d-md-flex align-items-center">
		          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18">
		            	<div class="icon"><span class="flaticon-doctor"></span></div>
		              <div class="text">
		                <strong class="number" data-number="30">0</strong>
		                <span>Years of Excellence</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18">
		            	<div class="icon"><span class="flaticon-doctor"></span></div>
		              <div class="text">
		                <strong class="number" data-number="1200">0</strong>
		                <span>Students</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18">
		            	<div class="icon"><span class="flaticon-doctor"></span></div>
		              <div class="text">
		                <strong class="number" data-number="100">0</strong>
		                <span>Staff</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18">
		            	<div class="icon"><span class="flaticon-doctor"></span></div>
		              <div class="text">
		                <strong class="number" data-number="2">0</strong>
		                <span>Schools</span>
		              </div>
		            </div>
		          </div>
	          </div>
          </div>
        </div>
    	</div>
    </section>
		
		<section class="ftco-section testimony-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            <h2 class="mb-4">Parent Says About Us</h2>
          </div>
        </div>
        <div class="row ftco-animate justify-content-center">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel">
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img mr-4" style="background-image: url(images/man.png)">
                  </div>
                  <div class="text ml-2">
                  	<span class="quote d-flex align-items-center justify-content-center">
                    </span>
                    <p>The teachers are Professional, caring and well organized. The admissions process was outstanding, they really care and truly want the best for your child.</p>
                    <p class="name">Hemanth Kumar</p>
                    <span class="position">Father</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img mr-4" style="background-image: url(images/woman.png)">
                  </div>
                  <div class="text ml-2">
                  	<span class="quote d-flex align-items-center justify-content-center">
                    </span>
                    <p>Every day my children are looking forward to coming to school. They very much enjoy their time in school and learning new things each and every day.</p>
                    <p class="name">Roopa Gangadhar</p>
                    <span class="position">Mother</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap d-flex">
                  <div class="user-img mr-4" style="background-image: url(images/man.png)">
                  </div>
                  <div class="text ml-2">
                  	<span class="quote d-flex align-items-center justify-content-center">
                    </span>
                    <p>Since joining the Nursery my daughter has developed in so many ways. She is more confident and balanced.</p>
                    <p class="name">Ajentheran Sreeharan</p>
                    <span class="position">Father</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

		<section class="ftco-gallery">
    	<div class="container-wrap">
    		<div class="row no-gutters">
					<div class="col-md-3 ftco-animate">
						<a href="images/foot1.png" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/foot1.png);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="images/foot2.png" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/foot2.png);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="images/foot3.png" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/foot3.png);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
					<div class="col-md-3 ftco-animate">
						<a href="images/foot4.png" class="gallery image-popup img d-flex align-items-center" style="background-image: url(images/foot4.png);">
							<div class="icon mb-4 d-flex align-items-center justify-content-center">
    						<span class="icon-instagram"></span>
    					</div>
						</a>
					</div>
        </div>
    	</div>
    </section>

		
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
       
        <div class="row">
          <div class="col-md-12 text-center">

            <p>
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> Shanthinikethana School, All Rights Reserved. </p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>