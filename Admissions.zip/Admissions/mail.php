<?php
if(isset($_POST["submit"]))
{
	$parentName = $_POST['parentName'];
	$studentName = $_POST['studentName'];
	$email = $_POST['email'];
	$phone = $_POST['number'];
	$board = $_POST['Board'];
	$query = $_POST['Queries'];
	$email1 = 'madhuraas08@gmail.com';
	$email2 = 'sesgirinagar@gmail.com';
	$email3 = 'jprashant28282828@gmail.com';
	

require './PHPMailer/PHPMailerAutoload.php';

  
$mail = new PHPMailer;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls'; 
$mail->SMTPAuth = true;
$mail->Username = "jprashant28282828@gmail.com"; // Your Gmail address.
$mail->Password = "Prashant1999$"; // Your Gmail login password
$mail->setFrom('Shanthinikethana School', 'SS');
$mail->addAddress($email1);
$mail->addAddress($email2);
$mail->Subject = "Your form has been succesfully submitted with us.";
$mail->Body = "Parent Name :- $parentName
Student Name :- $studentName
Board :- $board
Sender Email :- $email
Sender Phone Number :- $phone
Message :-
$query
"; // Set a plain text body.


if ($mail->send()) {
echo  "<script>alert('We have got your message.We will contact you soon');
window.location.href='index.php';
</script>";
} 
else {
    echo "Mailer Error: " . $mail->ErrorInfo;
}
}
?>